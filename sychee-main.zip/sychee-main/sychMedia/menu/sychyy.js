[{
  nameBot: "sychyyBotz",
  nameown: "yudaD0yy"
}]
